from math_operations import calculator,add,sub,divide,multiply

calculator()

print(add(10,20))

print(sub(10,20))
print(divide(20,10))
print(multiply(10,20))


def calculator():
    print("Performing calculation...")

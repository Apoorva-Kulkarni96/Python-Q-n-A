math_operations/
│
├── __init__.py          # Exposes add, sub, multiply, divide
├── calculator.py        # Calls all operations
│
├── basic/
│   ├── __init__.py
│   ├── addition.py      # add(a, b)
│   └── subtraction.py   # subtract(a, b)
│
└── advanced/
    ├── __init__.py
    ├── multiplication.py # multiply(a, b)
    └── division.py       # divide(a, b)
